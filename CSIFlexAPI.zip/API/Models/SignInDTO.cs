using System.ComponentModel.DataAnnotations;

namespace Models
{
    public class SignInDTO
    {
        public string UserName {get; set;}
        public string Password {get; set;}
    }
}
